package com.ssg.kms.wiki;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssg.kms.alarm.wiki.WikiAlarmService;
import com.ssg.kms.category.Category;
import com.ssg.kms.category.CategoryRepository;
import com.ssg.kms.like.wiki.WikiLikeRepository;
import com.ssg.kms.log.WikiLogRepository;
import com.ssg.kms.log.WikiLogService;
import com.ssg.kms.star.wiki.WikiStarRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class WikiService {
	
    private final WikiRepository wikiRepository;
    private final WikiLikeRepository wikiLikeRepository;
    private final WikiStarRepository wikiStarRepository;
    private final WikiLogRepository wikiLogRepository;
    private final CategoryRepository categoryRepository;
    
    private final WikiLogService wikiLogService;
    private final WikiAlarmService wikiAlarmService;
    
    @Transactional
    public Wiki createWiki(WikiDTO wikiDto, Long userId) {
    	
    	Category category = createCategory(wikiDto.getCategory());
    	
    	Wiki wiki = Wiki.builder()
    			.wikiTitle(wikiDto.getTitle())
    			.wikiContent(wikiDto.getContent())
    			.wikiCreateDt(new Date())
    			.userId(userId)
    			.category(category)
    			.tableId(1L)
    			.build();
    	
    	wikiRepository.save(wiki);
    	wikiLogService.createWikiLog(wiki, userId);
    	    	
		return wiki;
    }
    
    @Transactional
    public Wiki createTableWiki(Long tableId, WikiTableUserIdDTO wikiTableUserIdDto, Long userId) {
    	
    	Category category = createCategory(wikiTableUserIdDto.getCategory());
    	
    	Wiki wiki = Wiki.builder()
    			.wikiTitle(wikiTableUserIdDto.getTitle())
    			.wikiContent(wikiTableUserIdDto.getContent())
    			.wikiCreateDt(new Date())
    			.userId(userId)
    			.category(category)
    			.tableId(tableId)
    			.build();
    	
    	wikiRepository.save(wiki);
    	wikiLogService.createWikiLog(wiki, userId);
    	   
/// 알람 /////////////   	
    	List<Long> tableUserIds = wikiTableUserIdDto.getUserIds();
    	wikiAlarmService.createAlarm(wiki, tableUserIds, userId);
/////////////////////    	
		return wiki;
    }

    
    @Transactional(readOnly = true)
    public Wiki readWiki(Long wikiId, Long userId) {
		return wikiRepository.findById(wikiId).get();
    }
    
    @Transactional(readOnly = true)
    public List<Wiki> readAllWiki(Long userId) {
		return wikiRepository.findAll();
    }
    
    @Transactional(readOnly = true)
    public List<Wiki> readMyWiki(Long userId) {
		return wikiRepository.findAllByUserId(userId);
    }
    
    @Transactional(readOnly = true)
    public List<Wiki> readPublicWiki(Long tableId, Long userId) {
		return wikiRepository.findAllByTableId(tableId);
    }
    
    @Transactional(readOnly = true)
    public List<Wiki> readTableWiki(Long tableId, Long userId) {
    	
    	List<Wiki> wikis = wikiRepository.findAllByTableId(tableId);
    	List<Long> wikiIds = wikiRepository.findWikiIdAllByTableId(tableId);
    	
    	wikiAlarmService.deleteAlarm(wikiIds, userId);
   
		return wikiRepository.findAllByTableId(tableId);
    }
    
//    @Transactional(readOnly = true)
//    public List<Wiki> readAllTableWiki(Optional<User> user) {
//    	List<Long> tableIds = tableUserRepository.findTableIdAllByUserId(user.get().getId());
//    	return wikiRepository.findAllByTableIdIn(tableIds);
//    }
    
    @Transactional(readOnly = true)
    public List<Wiki> readUserPublicWiki(Long userId, Long tableId) {
    	
		return wikiRepository.findAllByTableIdAndUserId(tableId, userId);
    }

    
    @Transactional
    public Wiki updateWiki(Long wikiId, WikiDTO wikiDto, Long userId) {
    	Wiki wiki = wikiRepository.findById(wikiId).get();
    	Category category = createCategory(wikiDto.getCategory());
    	
    	wiki.setWikiTitle(wikiDto.getTitle());
    	wiki.setWikiContent(wikiDto.getContent());
    	wiki.setWikiCreateDt(new Date());
    	wiki.setCategory(category);
    	
    	wikiRepository.save(wiki);
    	wikiLogService.createWikiLog(wiki, userId);
    	
    	
		return wiki;
    }

    @Transactional
    public Wiki deleteWiki(Long wikiId, Long userId) {
    	Wiki wiki = wikiRepository.findById(wikiId).get();
    	
    	wikiLikeRepository.deleteAllByWikiWikiId(wikiId);
    	wikiStarRepository.deleteAllByWikiWikiId(wikiId);
    	wikiLogRepository.deleteAllByWikiWikiId(wikiId);

    	wikiAlarmService.deleteAlarmByWikiId(wikiId);
    	
    	wikiRepository.deleteById(wikiId);
    	return wiki;
    }
    
    @Transactional
    public List<Wiki> searchWiki(String searchKeyword, Long userId){
        return wikiRepository.findAllByWikiTitleContaining(searchKeyword);
    }   
    
    @Transactional
    public List<String> searchAllWiki(Long userId){
        return wikiRepository.findAllWikiTitles();
    }   
    
 // 카테고리 생성
    public Category createCategory(String categoryName){

    	Optional<Category> foundCategory = categoryRepository.findByName(categoryName);
    	Category category;
    	
    	if(foundCategory.isEmpty()) {
    		category = Category.builder()
    				.name(categoryName)
    				.build();    				
    	} else {
    		category = foundCategory.get();
    	}
    	
    	return categoryRepository.save(category);
    }
}
